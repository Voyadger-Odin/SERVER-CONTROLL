# Contributors

The following people have contributed to the development of Rich:

<!-- Add your name below, sort alphabetically by surname. Link to Github profile / your home page. -->

- [Gregory Beauregard](https://github.com/GBeauregard/pyffstream)
- [Darren Burns](https://github.com/darrenburns)
- [Pete Davison](https://github.com/pd93)
- [James Estevez](https://github.com/jstvz)
- [Oleksis Fraga](https://github.com/oleksis)
- [Kenneth Hoste](https://github.com/boegel)
- [Finn Hughes](https://github.com/finnhughes)
- [Josh Karpel](https://github.com/JoshKarpel)
- [Andrew Kettmann](https://github.com/akettmann)
- [Hedy Li](https://github.com/hedythedev)
- [Alexander Mancevice](https://github.com/amancevice)
- [Will McGugan](https://github.com/willmcgugan)
- [Nathan Page](https://github.com/nathanrpage97)
- [Avi Perl](https://github.com/avi-perl)
- [Laurent Peuch](https://github.com/psycojoker)
- [Kylian Point](https://github.com/p0lux)
- [Kyle Pollina](https://github.com/kylepollina)
- [Clément Robert](https://github.com/neutrinoceros)
- [Tushar Sadhwani](https://github.com/tusharsadhwani)
- [Tim Savage](https://github.com/timsavage)
- [Nicolas Simonds](https://github.com/0xDEC0DE)
- [Gabriele N. Tornetta](https://github.com/p403n1x87)
- [Patrick Arminio](https://github.com/patrick91)
