# Examples

This directory contains various demonstrations various Rich features. To run them, make sure Rich is installed, then enter `python example.py` on the command line.

Be sure to check the source!
