rich.style
==========

.. automodule:: rich.style
    :members:
    :special-members: __call__

