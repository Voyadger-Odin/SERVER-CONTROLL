rich.markup
===========

.. automodule:: rich.markup
    :members:
