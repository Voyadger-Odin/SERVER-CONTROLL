rich.panel
==========

.. automodule:: rich.panel
    :members: Panel

