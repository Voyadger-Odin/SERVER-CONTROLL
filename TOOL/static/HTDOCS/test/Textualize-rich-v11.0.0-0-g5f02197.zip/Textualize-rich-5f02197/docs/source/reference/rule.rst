rich.rule
=========

.. automodule:: rich.rule
    :members:
