rich.segment
============

.. automodule:: rich.segment
    :members:
