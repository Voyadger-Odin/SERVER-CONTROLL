rich.prompt
===========

.. automodule:: rich.prompt
    :members:
