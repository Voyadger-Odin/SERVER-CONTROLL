rich.status
============

.. automodule:: rich.status
    :members:
